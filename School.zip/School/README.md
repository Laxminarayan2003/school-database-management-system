# School-DataBase-Management-System
* Install XAMPP and start Apache,MYSQL servers.
* Download the project,unzip and store it in "C:\xampp\htdocs" as "Home"
* Open url "localhost/phpmyadmin" and create database "school" and Import "school.sql" from C:\xampp\htdocs\Home\db" and the tables with some inserted tuples ,triggers,procedures will be created.
* After importing goto the url "localhost/Home",play with it.
* Done by Mark Sathish Pairdha(16CS01032) and Bikas Pachar(16CS01038),B.TECH(CSE),2016-2020,IIT Bhubaneswar
